/*
 * Pasta.cpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#include "Pasta.hpp"

Pasta::Pasta() {
	cout << "You are creating Pasta" << endl;
	dateOfBaking = new Date();
	mass = 25;
	cookLevel = 5;
	sauceIncluded = true;
	glutenFree = false;

	// TODO Auto-generated constructor stub

}

Pasta::~Pasta() {
	delete dateOfBaking;
	cout << "You are deleting Pasta" << endl;
	// TODO Auto-generated destructor stub
}

bool Pasta::setDateOfBaking(int theDay, int theMonth, int theYear){
	bool value = true;
	dateOfBaking->setDay(theDay);
	dateOfBaking->setMonth(theMonth);
	dateOfBaking->setYear(theYear);
	return value;
}
bool Pasta::setMass(float aFloat){
	bool value = false;
	if(aFloat < 0){
		cout << "Mass of Pasta must be greater than zero." << endl;
	}
	else{
		value = true;
		mass = aFloat;
	}
	return value;
}
bool Pasta::setCookLevel(int anInt){
	bool value = false;
	if(anInt < 0 || anInt > 10){
		cout << "Cook Level cannot be negative or greater than 10." << endl;
	}
	else{
		value = true;
		cookLevel = anInt;
	}
	return value;
}
void Pasta::setSauceIncluded(bool aBool){
	sauceIncluded = aBool;
}
void Pasta::setGlutenFree(bool aBool){
	glutenFree = aBool;
}

Date *Pasta::getDateOfBaking(void){
	return dateOfBaking;
}
float Pasta::getMass(void){
	return mass;
}
int Pasta::getCookLevel(void){
	return cookLevel;
}
bool Pasta::getSauceIncluded(void){
	return sauceIncluded;
}
bool Pasta::getGlutenFree(void){
	return glutenFree;
}
