/*
 * Fettucine.hpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#ifndef FETTUCINE_HPP_
#define FETTUCINE_HPP_

#include "Pasta.hpp"
#include <iostream>
using namespace std;

class Fettucine: public Pasta {
public:
	Fettucine();
	virtual ~Fettucine();
	int getAvgLength(void);
	float getWidth(void);
	float getThickness(void);
	bool getTwisted(void);

	bool setLength(int anInt);
	bool setWidth(float aFloat);
	bool setThickness(float aFloat);
	void tsetTwisted(bool aBool);
private:
	int avgLength;
	float width;
	float thickness;
	bool twisted;
};

#endif /* FETTUCINE_HPP_ */
