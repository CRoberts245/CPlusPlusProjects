/*
 * Ravioli.cpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#include "Ravioli.hpp"

Ravioli::Ravioli() {
	meatInside = true;
	cheeseInside = true;
	width = 4;
	height = 4;
	ridges = 10;
	cout << "You are creating Ravioli" << endl;
	// TODO Auto-generated constructor stub

}

Ravioli::~Ravioli() {
	cout << "You are deleting Ravioli" << endl;
	// TODO Auto-generated destructor stub
}

void Ravioli::setMeatInside(bool aBool){
	meatInside = aBool;
}
void Ravioli::setCheeseInside(bool aBool){
	cheeseInside = aBool;
}
bool Ravioli::setWidth(int anInt){
	bool value = false;
		if(anInt < 1 || anInt > 10){
			cout << "Width cannot be less than 1 or greater than 10." << endl;
		}
		else{
			value = true;
			width = anInt;
		}
		return value;
}
bool Ravioli::setHeight(int anInt){
	bool value = false;
		if(anInt < 1 || anInt > 10){
			cout << "Height cannot be negative or greater than 10." << endl;
		}
		else{
			value = true;
			height = anInt;
		}
		return value;
}
bool Ravioli::setRidges(int anInt){
	bool value = false;
	if (anInt < 10 || anInt > 100) {
		cout << "Number of ridges cannot be less than 10 or greater than 100."
				<< endl;
	} else {
		value = true;
		ridges = anInt;
	}
	return value;
}

bool Ravioli::getMeatInside(void){
	return meatInside;
}
bool Ravioli::getCheeseInside(void){
	return cheeseInside;
}
int Ravioli::getWidth(void){
	return width;
}
int Ravioli::getHeight(void){
	return height;
}
int Ravioli::getRidges(void){
	return ridges;
}
