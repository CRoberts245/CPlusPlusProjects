/*
 * Pasta.hpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#ifndef PASTA_HPP_
#define PASTA_HPP_
#include <iostream>
#include <vector>
#include "Date.hpp"
using namespace std;
class Pasta {
public:
	Pasta();
	virtual ~Pasta();

	bool setDateOfBaking(int theDay, int theMonth, int theYear);
	bool setMass(float aFloat);
	bool setCookLevel(int anInt);
	void setSauceIncluded(bool aBool);
	void setGlutenFree(bool aBool);

	Date *getDateOfBaking(void);
	float getMass(void);
	int getCookLevel(void);
	bool getSauceIncluded(void);
	bool getGlutenFree(void);
private:
	Date *dateOfBaking;
	float mass;
	int cookLevel;
	bool sauceIncluded;
	bool glutenFree;
};

#endif /* PASTA_HPP_ */
