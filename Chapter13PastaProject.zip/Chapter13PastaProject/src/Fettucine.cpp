/*
 * Fettucine.cpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#include "Fettucine.hpp"

Fettucine::Fettucine() {
	cout << "You are creating Fettucine" << endl;
	avgLength = 5;
	width = 5;
	thickness = 5;
	twisted = false;
	// TODO Auto-generated constructor stub

}

Fettucine::~Fettucine() {
	cout << "You are deleting Fettucine" << endl;
	// TODO Auto-generated destructor stub
}

int Fettucine::getAvgLength(void){
	return avgLength;
}
float Fettucine::getWidth(void){
	return width;
}
float Fettucine::getThickness(void){
	return thickness;
}
bool Fettucine::getTwisted(void){
	return twisted;
}

bool Fettucine::setLength(int anInt){
	bool value = false;
	if (anInt < 1 || anInt > 10) {
		cout << "Length cannot be less than 1 or greater than 10." << endl;
	} else {
		value = true;
		avgLength = anInt;
	}
	return value;
}
bool Fettucine::setWidth(float aFloat){
	bool value = false;
	if (aFloat < 1 || aFloat > 10) {
		cout << "Width cannot be less than 1 or greater than 10." << endl;
	} else {
		value = true;
		width = aFloat;
	}
	return value;
}
bool Fettucine::setThickness(float aFloat){
	bool value = false;
	if (aFloat < 1 || aFloat > 10) {
		cout << "Thickness cannot be less than 1 or greater than 10." << endl;
	} else {
		value = true;
		thickness = aFloat;
	}
	return value;
}
void Fettucine::tsetTwisted(bool aBool){
	twisted = aBool;
}
