/*
 * Tortelloni.hpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#ifndef TORTELLONI_HPP_
#define TORTELLONI_HPP_

#include "Pasta.hpp"
#include "Date.hpp"
#include <iostream>
using namespace std;

class Tortelloni: public Pasta {
public:
	Tortelloni();
	virtual ~Tortelloni();
	int getStuffingLevel(void);
	bool getHandmade(void);
	string getStuffingType(void);
	int getRidges(void);
	Date* getStuffingDate(void);

	bool setStuffingLevel(int anInt);
	void setHandmade(bool aBool);
	bool setStuffingType(string aString);
	bool setRidges(int anInt);
	bool setStuffingDate(int theDay, int theMonth, int theYear);
private:
	int stuffingLevel;
	bool handmade;
	string stuffingType;
	int ridges;
	Date* stuffingDate;
};

#endif /* TORTELLONI_HPP_ */
