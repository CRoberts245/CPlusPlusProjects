/*
 * Date.cpp
 *
 *  Created on: Mar 2, 2017
 *      Author: student
 */

#include "Date.hpp"
#include <iostream>
#include <sstream>
using namespace std;

Date::Date() {
	day = 1;
	month = 1;
	year = 1970;
	strDate = getDateString(1, 1, 1970);
	cout << "You are creating a date." << endl;
	// TODO Auto-generated constructor stub

}
Date::Date(int theDay, int theMonth, int theYear){
	day = theDay;
	month = theMonth;
	year = theYear;
	strDate = getDateString(theDay,theMonth,theYear);
	cout << "You are creating a date." << endl;
}

Date::~Date() {
	cout << "You are deleting a date." << endl;
	// TODO Auto-generated destructor stub
}

int Date::getYear(void) {
	return year;
}
int Date::getMonth(void) {
	return month;
}
int Date::getDay(void) {
	return day;
}
bool Date::setYear(int anInt) {
	bool returnValue = true;
	year = anInt;
	return returnValue;
}
bool Date::setMonth(int anInt) {
	bool returnValue = true;
	month = anInt;
	return returnValue;
}
bool Date::setDay(int anInt) {
	bool returnValue = true;
	day = anInt;
	return returnValue;
}

string Date::getDateString(int theDay, int theMonth, int theYear){
	string aDay;
	string aMonth;
	string aYear;
	string Total;
	ostringstream convert;
	convert << theDay;
	aDay = convert.str();
	convert.str("");
	convert << theMonth;
	aMonth = convert.str();
	convert.str("");
	convert << theYear;
	aYear = convert.str();
	convert.str("");
	Total = aMonth + "/" + aDay + "/" + aYear;
	return Total;

}
