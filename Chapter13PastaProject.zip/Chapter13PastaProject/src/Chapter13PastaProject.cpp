//============================================================================
// Name        : Chapter13PastaProject.cpp
// Description : Project illustrating class basics
// Author      : Roberts, Cameron
// Date        : 3/7/2017
// Extra Credit: No
// IDE			: Eclipse
// OS			: Windows 7
//============================================================================

#include <iostream>
#include <vector>
#include "Pasta.hpp"
#include "Penne.hpp"
#include "Ravioli.hpp"
#include "Date.hpp"
#include "Utilities.hpp"
using namespace std;

int main() {
	int objectNumber = 0;
	while (objectNumber != -1) {
		vector<Penne*> myPenne;
		objectNumber = inputInt("How many objects would you like to create?(1-20, -1 to Exit)", 1,
				20, -1);
		if(objectNumber != -1){
			cout << "Vector of Pointers to Class Penne(Inherits from Pasta): "
					<< endl;
			cout << "Constructors cout: " << endl;
			for (int i = 0; i < objectNumber; i++) {
				cout << i + 1 << ") ";
				Penne *newPenne = new Penne();
				cout << endl;
				newPenne->setCookLevel(getRandomInt(0, 10));
				newPenne->setCutAngle(getRandomInt(45, 90));
				newPenne->setDateOfBaking(getRandomInt(1, 12),
						getRandomInt(1, 28), getRandomInt(2010, 2017));
				newPenne->setGlutenFree(false);
				newPenne->setHeight(getRandomInt(1, 10));
				newPenne->setMass(getRandomInt(10, 20));
				newPenne->setRidges(getRandomInt(10, 100));
				newPenne->setSauceIncluded(true);
				newPenne->setTubeDiameter(getRandomInt(1, 3));
				myPenne.push_back(newPenne);
			}//for
			cout << "Destructors cout:" <<endl;
			for (int i = 0; i < objectNumber; i++) {
				cout << i + 1 << ") ";
				delete myPenne[i];
				cout << endl;
			}//for
			myPenne.clear();



			Ravioli *tempRavioliPointer;
			Ravioli *arrayOfRavioli[objectNumber];
			cout << "Array of Pointers to Class Ravioli(Inherits from Pasta): " << endl;
			cout << "Constructors cout: " << endl;
			for(int i = 0; i < objectNumber; i++){
				cout << i+1 << ") ";
				tempRavioliPointer = new Ravioli();
				cout << endl;
				tempRavioliPointer->setDateOfBaking(getRandomInt(1, 12),
								getRandomInt(1, 28), getRandomInt(2010, 2017));
				tempRavioliPointer->setCookLevel(getRandomInt(0, 10));
				tempRavioliPointer->setMass(getRandomInt(10, 20));
				tempRavioliPointer->setSauceIncluded(true);
				tempRavioliPointer->setGlutenFree(false);
				tempRavioliPointer->setCheeseInside(true);
				tempRavioliPointer->setHeight(getRandomInt(1, 10));
				tempRavioliPointer->setWidth(getRandomInt(1, 10));
				tempRavioliPointer->setMeatInside(false);
				tempRavioliPointer->setRidges(getRandomInt(10, 100));
				arrayOfRavioli[i] = tempRavioliPointer;
			}//for
			cout << "Destructors cout:" <<endl;
			for(int i = 0; i < objectNumber; i++){
				cout << i+1 << ") ";
				delete arrayOfRavioli[i];
				cout << endl;
			}//for

		}//if

	}

	cout << "Program Ending, Goodbye!" << endl; // prints !!!Hello World!!!
	return 0;
}
