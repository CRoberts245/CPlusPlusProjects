/*
 * Tortelloni.cpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#include "Tortelloni.hpp"

Tortelloni::Tortelloni() {
	cout << "You are creating Tortelloni" << endl;
	stuffingLevel = 5;
	handmade = true;
	stuffingType = "Meat Sauce";
	ridges = 50;
	stuffingDate = new Date();
	// TODO Auto-generated constructor stub

}

Tortelloni::~Tortelloni() {
	cout << "You are deleting Tortelloni" << endl;
	delete stuffingDate;
	// TODO Auto-generated destructor stub
}

int Tortelloni::getStuffingLevel(void){
	return stuffingLevel;
}
bool Tortelloni::getHandmade(void){
	return handmade;
}
string Tortelloni::getStuffingType(void){
	return stuffingType;
}
int Tortelloni::getRidges(void){
	return ridges;
}
Date* Tortelloni::getStuffingDate(void){
	return stuffingDate;
}

bool Tortelloni::setStuffingLevel(int anInt){
	bool value = false;
		if (anInt < 1 || anInt > 10) {
			cout << "Stuffing Level cannot be less than 1 or greater than 10." << endl;
		} else {
			value = true;
			stuffingLevel = anInt;
		}
		return value;
}
void Tortelloni::setHandmade(bool aBool){
	handmade = aBool;
}
bool Tortelloni::setStuffingType(string aString){
	stuffingType = "Meat Sauce";
	bool value = true;
	return value;
}
bool Tortelloni::setRidges(int anInt){
	bool value = false;
	if (anInt < 10 || anInt > 100) {
		cout << "Number of ridges cannot be less than 10 or greater than 100."
				<< endl;
	} else {
		value = true;
		ridges = anInt;
	}
	return value;
}
bool Tortelloni::setStuffingDate(int theDay, int theMonth, int theYear){
	stuffingDate->setDay(theDay);
	stuffingDate->setMonth(theMonth);
	stuffingDate->setYear(theYear);
	bool value = true;
	return value;
}
