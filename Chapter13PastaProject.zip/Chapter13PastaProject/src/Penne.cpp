/*
 * Penne.cpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#include "Penne.hpp"

Penne::Penne() {
	height = 5;
	tubeDiameter = 2;
	cutAngle = 45;
	ridges = 10;
	cout << "You are creating Penne" << endl;
	// TODO Auto-generated constructor stub

}

Penne::~Penne() {
	cout << "You are deleting Penne" << endl;
	// TODO Auto-generated destructor stub
}

int Penne::getHeight(void){
	return height;
}
float Penne::getTubeDiameter(void){
	return tubeDiameter;
}
int Penne::getCutAngle(void){
	return cutAngle;
}
int Penne::getRidges(void){
	return ridges;
}

bool Penne::setHeight(int anInt){
	bool value = false;
	if (anInt < 1 || anInt > 10) {
		cout << "Height cannot be less than 1 or greater than 10." << endl;
	}
	else {
		value = true;
		height = anInt;
	}
	return value;
}
bool Penne::setTubeDiameter(int anInt){
	bool value = false;
	if (anInt < 1 || anInt > 3) {
		cout << "Tube Diameter cannot be less than 1 or greater than 3." << endl;
	} else {
		value = true;
		tubeDiameter = anInt;
	}
	return value;
}
bool Penne::setCutAngle(int anInt){
	bool value = false;
	if (anInt < 45 || anInt > 90) {
		cout << "Cut Angle cannot be less than 45 or greater than 90." << endl;
	}
	else {
		value = true;
		cutAngle = anInt;
	}
	return value;
}
bool Penne::setRidges(int anInt){
	bool value = false;
	if (anInt < 10 || anInt > 100) {
		cout << "Number of ridges cannot be less than 10 or greater than 100."
				<< endl;
	}
	else {
		value = true;
		ridges = anInt;
	}
	return value;
}
