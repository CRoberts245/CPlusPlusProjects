/*
 * Ravioli.hpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#ifndef RAVIOLI_HPP_
#define RAVIOLI_HPP_

#include "Pasta.hpp"
#include <iostream>
using namespace std;

class Ravioli: public Pasta {
public:
	Ravioli();
	virtual ~Ravioli();

	void setMeatInside(bool aBool);
	void setCheeseInside(bool aBool);
	bool setWidth(int anInt);
	bool setHeight(int anInt);
	bool setRidges(int anInt);

	bool getMeatInside(void);
	bool getCheeseInside(void);
	int getWidth(void);
	int getHeight(void);
	int getRidges(void);
private:
	bool meatInside;
	bool cheeseInside;
	int width;
	int height;
	int ridges;
};

#endif /* RAVIOLI_HPP_ */
