/*
 * Date.hpp
 *
 *  Created on: Mar 2, 2017
 *      Author: student
 */

#ifndef DATE_HPP_
#define DATE_HPP_
#include <iostream>
using namespace std;
class Date {
public:
	Date();
	Date(int theDay, int theMonth, int theYear);
	virtual ~Date();

	int getYear(void);
	int getMonth(void);
	int getDay(void);
	bool setYear(int anInt);
	bool setMonth(int anInt);
	bool setDay(int anInt);
	string strDate;
	string getDateString(int theDay, int theMonth, int theYear);
private:
	int year;
	int month;
	int day;
};

#endif /* DATE_HPP_ */
