/*
 * Penne.hpp
 *
 *  Created on: Mar 7, 2017
 *      Author: Roberts
 */

#ifndef PENNE_HPP_
#define PENNE_HPP_

#include "Pasta.hpp"
#include <iostream>
#include <vector>
using namespace std;
class Penne: public Pasta {
public:
	Penne();
	virtual ~Penne();
	int getHeight(void);
	float getTubeDiameter(void);
	int getCutAngle(void);
	int getRidges(void);

	bool setHeight(int anInt);
	bool setTubeDiameter(int anInt);
	bool setCutAngle(int anInt);
	bool setRidges(int anInt);
private:
	int height;
	float tubeDiameter;
	int cutAngle;
	int ridges;
};

#endif /* PENNE_HPP_ */
