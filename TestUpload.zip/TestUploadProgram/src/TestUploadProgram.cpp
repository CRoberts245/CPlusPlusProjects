//============================================================================
// Name        : TestUploadProgram.cpp
// Author      : Cameron Roberts
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "utilities.hpp"
using namespace std;

int main() {
	int y = getRandomInt(0, 101);
	cout << y;
}
