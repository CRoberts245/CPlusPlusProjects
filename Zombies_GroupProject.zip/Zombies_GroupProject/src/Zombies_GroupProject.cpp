//============================================================================
// Name        : Zombies_GroupProject.cpp
// Author      : Cameron Roberts
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "utilities.hpp"

using namespace std;



struct Zombie{
	string zName;
	int hp;
	int power;
	string movement;

};



int main() {
	vector<Zombie*> Zombies;
	Zombie *tempZombie;

	int numOfZombies = inputInt("How many Zombies would you like?", 1, 10, -1);



	for(int i = 0; i < numOfZombies; i++){
		tempZombie = new Zombie;
		tempZombie->hp = getRandomInt(1, 100);
		tempZombie->power = getRandomInt(1, 100);
		tempZombie->zName = inputString("Enter the Zombie name: ", 1, 10);
		int status = inputInt("Movement type(0-3):", 0, 3, -1);
		if(status == 0){
			tempZombie->movement = "Running";
		}
		else if(status == 1){
			tempZombie->movement = "Crawling";
		}
		else if(status == 2){
			tempZombie->movement = "Swimming";
		}
		else if(status == 3){
			tempZombie->movement = "Flying";
		}

		Zombies.push_back(tempZombie);
	}
	for(int i = 0; i < numOfZombies; i++){

		cout << Zombies[i]->zName;
		cout << "  HP: " << Zombies[i]->hp;
		cout << "  POWER: " << Zombies[i]->power;
		cout << "   " << Zombies[i]->movement << endl;
	}

	for(int i = 0; i < numOfZombies; i++){
		cout << "Aaarrgghhhhhh, grrrrr " << Zombies[i]->zName << " is deleted!" << endl;
		delete Zombies[i];
	}
}
