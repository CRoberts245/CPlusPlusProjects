/*
 * LinkedList.hpp
 *
 *  Created on: May 25, 2017
 *      Author: Roberts
 */

#ifndef LINKEDLIST_HPP_
#define LINKEDLIST_HPP_
#include <iostream>
using namespace std;

struct listNode{
	float data;
	listNode *Next;
};


class LinkedList {
public:
	LinkedList();
	virtual ~LinkedList();
	bool push_front(float);
	bool push_back(float);
	float pop_front(void);
	float pop_back(void);
	bool insert_sorted(float);
	int size(void);
	void print_list(void);
private:
	listNode *headPtr;


};

#endif /* LINKEDLIST_HPP_ */
