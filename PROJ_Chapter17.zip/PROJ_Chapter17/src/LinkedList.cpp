/*
 * LinkedList.cpp
 *
 *  Created on: May 25, 2017
 *      Author: Roberts
 */

#include "LinkedList.hpp"

LinkedList::LinkedList() {
	// TODO Auto-generated constructor stub
	headPtr = new listNode();
	headPtr->Next = NULL;
}

LinkedList::~LinkedList() {
	// TODO Auto-generated destructor stub
	delete headPtr;
}

bool LinkedList::push_back(float aFloat){
	bool insertComplete = true;
	listNode *newNode;
	newNode = new listNode;
	newNode->data = aFloat;
	newNode->Next = NULL;
	listNode * tnode = headPtr;
	if(headPtr->Next == NULL){
		headPtr->Next = newNode;
	}
	else{
			while(tnode->Next != NULL){
				tnode = tnode->Next;
			}
			tnode->Next = newNode;
	}
	return insertComplete;
}

bool LinkedList::push_front(float aFloat){
	listNode* newNode = new listNode();
	newNode->data = aFloat;
	bool flag = true;
	if(headPtr->Next == NULL){
		headPtr->Next = newNode;
		newNode->Next = NULL;
	}
	else{
		newNode->Next = headPtr->Next;
		headPtr->Next = newNode;
	}
	return flag;
}

bool LinkedList::insert_sorted(float aFloat){
	listNode *nodePtr = headPtr->Next;

	listNode *temp = new listNode();
	temp->data = aFloat;

	bool flag = true;
	while(true){
		if(headPtr->Next == NULL){
			this->push_back(aFloat);
			break;
		}
		else if(temp->data < nodePtr->data){
			this->push_front(aFloat);
			break;
		}
		else if(temp->data == nodePtr->data){
			if (nodePtr->Next == NULL) {
				this->push_back(aFloat);
			} else {
				temp->Next = nodePtr->Next;
				nodePtr->Next = temp;
			}
			break;
		}
		else if(temp->data > nodePtr->data && nodePtr->Next == NULL){
			this->push_back(aFloat);
			break;
		}
		else if(temp->data > nodePtr->data && nodePtr->Next->data > temp->data){
			if(nodePtr->Next == NULL){
				this->push_back(aFloat);
			}
			else{
				temp->Next = nodePtr->Next;
				nodePtr->Next = temp;
			}
			break;
		}
		else{
			nodePtr = nodePtr->Next;
		}
	}
	return flag;
}

int LinkedList::size(void){
	listNode * tnode = headPtr->Next;
	int counter = 0;
	while(tnode->Next != NULL){
		tnode = tnode->Next;
		counter++;
	}
	return counter;
}

float LinkedList::pop_back(void){
	listNode *tnode = headPtr;
	float data;
	while(tnode->Next->Next != NULL){
		tnode = tnode->Next;
	}
	data = tnode->Next->data;
	delete tnode->Next;
	tnode->Next = NULL;
	return data;

}

float LinkedList::pop_front(void){
	listNode *tnode = headPtr->Next;
	float data = tnode->data;
	headPtr->Next = tnode->Next;
	delete tnode;
	return data;
}

void LinkedList::print_list(void){
	listNode * tnode = headPtr;

	while(tnode->Next != NULL){
		tnode = tnode->Next;
		cout << tnode->data << endl;
	}
}
