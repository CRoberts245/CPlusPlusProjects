//============================================================================
// Name        : PROJ_Chapter17.cpp
// Author      : Cameron Roberts
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "LinkedList.hpp"
#include "Utilities.hpp"
using namespace std;

int main() {

	LinkedList myLinkedList;

	while(true){

		cout << "Enter Values to Linked List(-999 to exit): ";
		float theFloat = inputFloat("", -100, 100, -999);
		if(theFloat == -999){
			break;
		}
		else{
			myLinkedList.insert_sorted(theFloat);
		}
	}
	myLinkedList.print_list();
	int size = myLinkedList.size();
	for(int i = 0; i < size; i++){
		myLinkedList.pop_front();
	}
	cout << "Program Ending, Linked List Size: ";
	cout << myLinkedList.size() << endl;

	return 0;
}
