/*
 * Order.cpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#include "Order.hpp"

Order::Order(string aString) {
	// TODO Auto-generated constructor stub
	OrderDate = new Date();
	OrderNumber = aString;

}

Order::~Order() {
	// TODO Auto-generated destructor stub
	delete OrderDate;
}

string Order::getOrderNumber(void){//accessors and mutators
	return OrderNumber;
}
Date *Order::getOrderDate(void){
	return OrderDate;
}
string Order::getOrderCustomer(void){
	return OrderCustomer;
}
void Order::setOrderNumber(string aString){
	OrderNumber = aString;
}
void Order::setOrderDate(Date *aDate){
	OrderDate = aDate;
}
void Order::setOrderCustomer(string aString){
	OrderCustomer = aString;
}
string Order::getCustomerID(void){
	return CustomerID;
}
void Order::setCustomerID(string aString){
	CustomerID = aString;
}

