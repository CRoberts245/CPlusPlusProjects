//============================================================================
// Name        : PROJ_Chapter16.cpp
// Author      : Cameron Roberts
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <map>
#include <list>
#include <iomanip>
#include "Customer.hpp"
#include "Order.hpp"

using namespace std;

int main() {
	map<string, Customer*> theCustomers;
	list<Order*> theOrders;

	ifstream customerFin;

	customerFin.open("CustomerFile.txt");
	if (customerFin.fail()) {
		cout << "Failure to Open Customer File" << endl;
	} //if
	else {
		while (!customerFin.eof()) {
			Customer* TempCustomer = new Customer();
			string tempString;
			int tempYear;
			int tempMonth;
			int tempDay;

			customerFin >> tempString;
			TempCustomer->setCustomerNumber(tempString);
			customerFin >> tempString;
			TempCustomer->setCustomerName(tempString);
			customerFin >> tempString;
			TempCustomer->setEmail(tempString);
			customerFin >> tempYear;
			customerFin >> tempMonth;
			customerFin >> tempDay;
			Date *aDate = new Date(tempDay, tempMonth, tempYear);
			TempCustomer->setDateJoined(aDate);
			pair<map<string,Customer*>::iterator, bool> insertion;
			insertion = theCustomers.insert(pair<string, Customer*>(TempCustomer->getCustomerNumber(), TempCustomer));
		} //while
		customerFin.close();
	}
	ifstream orderFin;
	orderFin.open("OrderFile.txt");
	if (orderFin.fail()) {
		cout << "Failure to Open Order File" << endl;
		orderFin.close();
	} //if
	else {
		while (!orderFin.eof()) {

			string tempString;
			int tempYear;
			int tempMonth;
			int tempDay;

			orderFin >> tempString;
			Order* TempOrder = new Order(tempString);
			orderFin >> tempYear;
			orderFin >> tempMonth;
			orderFin >> tempDay;
			Date *aDate = new Date(tempDay, tempMonth, tempYear);
			TempOrder->setOrderDate(aDate);
			orderFin >> tempString;
			TempOrder->setCustomerID(tempString);
			theOrders.push_back(TempOrder);

		} //while
		orderFin.close();
	}//else


	list<Order*>::iterator OrderIterator;

	OrderIterator = theOrders.begin();


	cout << "Order Report" << endl;
	for (unsigned int i = 0; i < theOrders.size(); i++) {

		cout << "=================================" << endl;

		cout << setw(12) << right << "Order ID";
		cout << setw(15) << right << "Customer ID";
		cout << setw(12) << right << "Order Date"<< endl;

		cout << setw(12) << right << "--------";
		cout << setw(15) << right << "-----------";
		cout << setw(12) << right << "-----------"<< endl;


		cout << setw(12) << right << (*OrderIterator)->getOrderNumber();
		cout << setw(15) << right << (*OrderIterator)->getCustomerID();
		cout << setw(12) << right << (*OrderIterator)->getOrderDate()->getDateStringThis() << endl;

		cout << "--------------" << endl;
		cout << setw(15) << right << "Customer";
		cout << setw(10) << right << "Email";
		cout << setw(22) << right << "Customer Date" << endl;
		cout << setw(15) << right << "--------";
		cout << setw(10) << right << "------";
		cout << setw(19) << right << "--------"<< endl;

		map<string, Customer*>::iterator searchIterator;
		searchIterator = theCustomers.find((*OrderIterator)->getCustomerID());
		if(searchIterator != theCustomers.end()){
			cout << setw(15) << right <<  theCustomers[(*OrderIterator)->getCustomerID()]->getCustomerName();
			cout << setw(18) << right << theCustomers[(*OrderIterator)->getCustomerID()]->getEmail();
			cout << setw(13) << right << theCustomers[(*OrderIterator)->getCustomerID()]->getDateJoined()->getDateStringThis() << endl;
		}
		OrderIterator++;
	}//for
	for(unsigned int i = 0; i < theOrders.size(); i++){
		delete theOrders.front();
		theOrders.pop_front();

	}
	theOrders.clear();

	map<string, Customer*>::iterator iter;
	for(iter = theCustomers.begin(); iter != theCustomers.end(); ++iter){
		delete iter->second;
	}

	return 0;
}
