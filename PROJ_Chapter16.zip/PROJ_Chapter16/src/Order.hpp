/*
 * Order.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef ORDER_HPP_
#define ORDER_HPP_
#include "Date.hpp"
#include "Customer.hpp"
#include <vector>
#include <fstream>
using namespace std;

class Order {
private:
	string OrderNumber;
	Date *OrderDate;
	string OrderCustomer;
	string CustomerID;

public:
	Order(string);
	virtual ~Order();
	string getOrderNumber(void);//accessors and mutators
	Date *getOrderDate(void);
	string getOrderCustomer(void);
	string getCustomerID(void);
	void setCustomerID(string);
	void setOrderNumber(string);
	void setOrderDate(Date*);
	void setOrderCustomer(string);

};

#endif /* ORDER_HPP_ */
