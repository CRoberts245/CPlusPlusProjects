/*
 * MedialItem.cpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#include "MedialItem.hpp"
#include <sstream>
MedialItem::MedialItem() {
	// TODO Auto-generated constructor stub

}

MedialItem::~MedialItem() {
	// TODO Auto-generated destructor stub
}

string MedialItem::getAuthorName(void){
	return AuthorName;
}
Date MedialItem::getPublicationDate(void){
	return PublicationDate;
}
string MedialItem::getISBNNumber(void){
	return ISBNNumber;
}
void MedialItem::setAuthorName(string aString){
	AuthorName = aString;
}
void MedialItem::setPublicationDate(Date aDate){
	PublicationDate = aDate;
}
void MedialItem::setISBNNumber(string aString){
	ISBNNumber = aString;
}

string MedialItem::whoAmI(void){
	return "mediaitem";
}
string MedialItem::getSpecial1(void){
	return ISBNNumber;
}
string MedialItem::getSpecial2(void){
	ostringstream convert;
	convert << this->getCustomerCost();
	string newCost = convert.str();
	convert.str("");
	return newCost;
}
