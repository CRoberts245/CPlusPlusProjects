/*
 * Order.cpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#include "Order.hpp"

Order::Order(string aString) {
	// TODO Auto-generated constructor stub
	OrderDate = new Date();
	OrderNumber = aString;
	readFoodItems();
	readMediaItems();
	readElectronicItems();

}

Order::~Order() {
	// TODO Auto-generated destructor stub
	delete OrderDate;
	for(int i = 0; i < ItemsInOrder.size(); i++){
		delete ItemsInOrder[i];
	}
	ItemsInOrder.clear();
}

string Order::getOrderNumber(void){//accessors and mutators
	return OrderNumber;
}
Date *Order::getOrderDate(void){
	return OrderDate;
}
Customer *Order::getOrderCustomer(void){
	return OrderCustomer;
}
void Order::setOrderNumber(string aString){
	OrderNumber = aString;
}
void Order::setOrderDate(Date *aDate){
	OrderDate = aDate;
}
void Order::setOrderCustomer(Customer* aCustomer){
	OrderCustomer = aCustomer;
}
string Order::getCustomerID(void){
	return CustomerID;
}
void Order::setCustomerID(string aString){
	CustomerID = aString;
}
void Order::readFoodItems(void){
	ifstream foodFin;
	foodFin.open("FoodItems.txt");
	if(foodFin.fail()){
		cout << "Failure to Open Food File" << endl;
	}
	else{
//		string tempString;
//		double tempDouble;
//		int tempYear;
//		int tempMonth;
//		int tempDay;

		while(!foodFin.eof()){
			string tempString;
			double tempDouble;
			int tempYear;
			int tempMonth;
			int tempDay;
			FoodItem *newFood = new FoodItem();
			foodFin >> tempString;
			newFood->setOrderNumber(tempString);
			foodFin >> tempString;
			newFood->setItemNumber(tempString);
			foodFin >> tempString;
			newFood->setItemDescription(tempString);
			foodFin >> tempDouble;
			newFood->setQuantity(tempDouble);
			foodFin >> tempDouble;
			newFood->setCustomerCost(tempDouble);
			foodFin >> tempDouble;
			newFood->setVendorCost(tempDouble);
			foodFin >> tempString;
			if(tempString == "Y"){
				newFood->setTaxExempt(true);
			}
			else{
				newFood->setTaxExempt(false);
			}
			foodFin >> tempYear;
			foodFin >> tempMonth;
			foodFin >> tempDay;
			Date aDate;
			aDate.setYear(tempYear);
			aDate.setMonth(tempMonth);
			aDate.setDay(tempDay);
			newFood->setExpirationDate(aDate);
			foodFin >> tempYear;
			newFood->setCalories(tempYear);
			foodFin >> tempYear;
			newFood->setFat(tempYear);
			if(newFood->getOrderNumber() == OrderNumber){
				ItemsInOrder.push_back(newFood);
			}
			else{
				delete newFood;
			}
		}
		foodFin.close();
	}

}
void Order::readMediaItems(void) {
	ifstream mediaFin;
	mediaFin.open("MediaItems.txt");
	if (mediaFin.fail()) {
		cout << "Failure to Open Food File" << endl;
	}//if
	else{
		string tempString;
		double tempDouble;
		int tempYear;
		int tempMonth;
		int tempDay;

		while(!mediaFin.eof()){
			MedialItem *newMedia = new MedialItem();
			mediaFin >> tempString;
			newMedia->setOrderNumber(tempString);
			mediaFin >> tempString;
			newMedia->setItemNumber(tempString);
			mediaFin >> tempString;
			newMedia->setItemDescription(tempString);
			mediaFin >> tempDouble;
			newMedia->setQuantity(tempDouble);
			mediaFin >> tempDouble;
			newMedia->setCustomerCost(tempDouble);
			mediaFin >> tempDouble;
			newMedia->setVendorCost(tempDouble);
			mediaFin >> tempString;
			if(tempString == "Y"){
				newMedia->setTaxExempt(true);
			}//if
			else{
				newMedia->setTaxExempt(false);
			}//else
			mediaFin >> tempYear;
			mediaFin >> tempMonth;
			mediaFin >> tempDay;
			Date aDate;
			aDate.setYear(tempYear);
			aDate.setMonth(tempMonth);
			aDate.setDay(tempDay);
			newMedia->setPublicationDate(aDate);
			mediaFin >> tempString;
			newMedia->setAuthorName(tempString);
			mediaFin >> tempString;
			newMedia->setISBNNumber(tempString);
			if (newMedia->getOrderNumber() == OrderNumber) {
				ItemsInOrder.push_back(newMedia);
			} else {
				delete newMedia;
			}
		}//while

	}//else
	mediaFin.close();

}

void Order::readElectronicItems(void){
	ifstream electronicFin;
	electronicFin.open("ElectronicItems.txt");
	if (electronicFin.fail()) {
		cout << "Failure to Open Food File" << endl;
	}//if
	else{
		string tempString;
		double tempDouble;
		int tempInt;
		Electronic tempValue;

		while(!electronicFin.eof()){
			ElectronicItem *newElectronic = new ElectronicItem();
			electronicFin >> tempString;
			newElectronic->setOrderNumber(tempString);
			electronicFin >> tempString;
			newElectronic->setItemNumber(tempString);
			electronicFin >> tempString;
			newElectronic->setItemDescription(tempString);
			electronicFin >> tempDouble;
			newElectronic->setQuantity(tempDouble);
			electronicFin >> tempDouble;
			newElectronic->setCustomerCost(tempDouble);
			electronicFin >> tempDouble;
			newElectronic->setVendorCost(tempDouble);
			electronicFin >> tempString;
			if(tempString == "Y"){
				newElectronic->setTaxExempt(true);
			}//if
			else{
				newElectronic->setTaxExempt(false);
			}//else
			electronicFin >> tempInt;
			switch(tempInt){
			case 1: tempValue = TV;
			break;
			case 2: tempValue = PS4;
			break;
			case 3: tempValue = DVDPLAYER;
			break;
			case 4: tempValue = PHONE;
			break;
			}
			newElectronic->setType(tempValue);
			electronicFin >> tempInt;
			newElectronic->setWarrantyMonths(tempInt);

			if (newElectronic->getOrderNumber() == OrderNumber) {
				ItemsInOrder.push_back(newElectronic);
			} else {
				delete newElectronic;
			}

		}//while
	}//else
	electronicFin.close();

}
double Order::getTotalOrder(string aString){
	double total = 0;
	for(unsigned int i = 0; i < ItemsInOrder.size(); i++){
		if(OrderNumber == aString){
			total += ItemsInOrder[i]->getQuantity()*ItemsInOrder[i]->getCustomerCost();
		}
	}
	return total;
}
