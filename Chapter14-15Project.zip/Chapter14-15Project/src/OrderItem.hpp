/*
 * OrderItem.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef ORDERITEM_HPP_
#define ORDERITEM_HPP_
#include <iostream>
using namespace std;

enum Electronic{
	TV,
	PS4,
	DVDPLAYER,
	PHONE
};

class OrderItem {
private:
	string OrderNumber;
	string ItemNumber;
	string ItemDescription;
	int Quantity;
	double VendorCost;
	bool TaxExempt;
	double CustomerCost;
public:
	OrderItem();
	virtual ~OrderItem();
	string getOrderNumber(void);
	string getItemNumber(void);
	string getItemDescription(void);
	int getQuantity(void);
	double getCustomerCost(void);
	double getVendorCost(void);
	bool getTaxExempt(void);
	void setOrderNumber(string);
	void setItemNumber(string);
	void setItemDescription(string);
	void setQuantity(double);
	void setCustomerCost(double);
	void setVendorCost(double);
	void setTaxExempt(bool);
	virtual string whoAmI(void) = 0;
	virtual string getSpecial1(void) = 0;
	virtual string getSpecial2(void) = 0;
};

#endif /* ORDERITEM_HPP_ */
