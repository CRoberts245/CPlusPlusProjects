//============================================================================
// Name        : Chapter14-15Project.cpp
// Author      : Cameron Roberts
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Customer.hpp"
#include "Order.hpp"
#include "OrderItem.hpp"
#include "ElectronicItem.hpp"
#include "FoodItem.hpp"
#include "MedialItem.hpp"
#include <iomanip>
#include <fstream>
using namespace std;

void printOrder(int anInt, vector<Order*> Orders);

int main(int argc, const char * argv[]) {
	if(argc > 2){
		cout << "Program Failure, Only takes 2 arguments" << endl;
	}
	else{
		vector<Customer*> theCustomers;
		vector<Order*> theOrders;
		ifstream customerFin;

		customerFin.open("CustomerFile.txt");
		if(customerFin.fail()){
			cout << "Failure to Open Customer File" << endl;
		}//if
		else{
			while(!customerFin.eof()){
				Customer* TempCustomer = new Customer();
				string tempString;
				int tempYear;
				int tempMonth;
				int tempDay;

				customerFin >> tempString;
				TempCustomer->setCustomerNumber(tempString);
				customerFin >> tempString;
				TempCustomer->setCustomerName(tempString);
				customerFin >> tempString;
				TempCustomer->setEmail(tempString);
				customerFin >> tempYear;
				customerFin >> tempMonth;
				customerFin >> tempDay;
				Date *aDate = new Date(tempDay, tempMonth, tempYear);
				TempCustomer->setDateJoined(aDate);
				theCustomers.push_back(TempCustomer);
			}//while
			customerFin.close();
			ifstream orderFin;
			orderFin.open("OrderFile.txt");
			if(orderFin.fail()){
				cout << "Failure to Open Order File" << endl;
				orderFin.close();
			}//if
			else{
				while(!orderFin.eof()){

					string tempString;
					int tempYear;
					int tempMonth;
					int tempDay;

					orderFin >> tempString;
					Order* TempOrder = new Order(tempString);
					orderFin >> tempYear;
					orderFin >> tempMonth;
					orderFin >> tempDay;
					Date *aDate = new Date(tempDay, tempMonth, tempYear);
					TempOrder->setOrderDate(aDate);
					orderFin >> tempString;
					TempOrder->setCustomerID(tempString);
					theOrders.push_back(TempOrder);

				}//while
				orderFin.close();

			}//else
			for(unsigned int i = 0; i < theOrders.size();i++){
				if(theOrders[i]->getCustomerID() == theCustomers[i]->getCustomerNumber()){
					theOrders[i]->setOrderCustomer(theCustomers[i]);
				}
				else{
					theOrders[i]->setOrderCustomer(NULL);
				}
			}



		}//else

		if(argc == 1){
			cout << "Order Report" << endl;
			for(unsigned int i = 0; i < theOrders.size();i++){

				cout << "=================================" << endl;

				cout << setw(15) << right << "Order ID";
				cout << setw(15) << right << "Customer ID";
				cout << setw(12) << right << "Order Date";
				cout << setw(15) << right << "Customer" << endl;

				cout << setw(15) << right << "--------";
				cout << setw(15) << right << "-----------";
				cout << setw(12) << right << "-----------";
				cout << setw(15) << right << "--------" << endl;

				cout << setw(15) << right << theOrders[i]->getOrderNumber();
				cout << setw(15) << right << theOrders[i]->getCustomerID();
				cout << setw(12) << right << theOrders[i]->getOrderDate()->getDateStringThis();
				cout << setw(15) << right << theOrders[i]->getOrderCustomer()->getCustomerName() << endl;

				cout << "--------------" << endl;

				cout << setw(21) << right << "Food Items Ordered:";
				cout << setw(20) << right << "Item Number";
				cout << setw(33) << right << "Item Description";
				cout << setw(11) << right << "Calories";
				cout << setw(12) << right << "Cost" << endl;

				cout << setw(41) << right << "-----------";
				cout << setw(33) << right << "--------------";
				cout << setw(11) << right << "--------";
				cout << setw(12) << right << "----" << endl;

				for(unsigned int j = 0; j < theOrders[i]->ItemsInOrder.size(); j++){
					if(theOrders[i]->ItemsInOrder[j]->whoAmI() == "fooditem"){
						cout << setw(41) << right << theOrders[i]->ItemsInOrder[j]->getItemNumber();
						cout << setw(33) << right << theOrders[i]->ItemsInOrder[j]->getItemDescription();
						cout << setw(11) << right << theOrders[i]->ItemsInOrder[j]->getSpecial1();
						cout << setw(12) << right << theOrders[i]->ItemsInOrder[j]->getSpecial2() << endl;
					}//if
					else{
					}//else

				}//for

				cout << "--------------" << endl;
				cout << setw(21) << right << "Media Items Ordered:";
				cout << setw(20) << right << "Item Number";
				cout << setw(33) << right << "Item Description";
				cout << setw(11) << right << "ISBN";
				cout << setw(12) << right << "Cost" << endl;

				cout << setw(41) << right << "-----------";
				cout << setw(33) << right << "--------------";
				cout << setw(11) << right << "----";
				cout << setw(12) << right << "----" << endl;

				for(unsigned int j = 0; j < theOrders[i]->ItemsInOrder.size(); j++){
					if(theOrders[i]->ItemsInOrder[j]->whoAmI() == "mediaitem"){
						cout << setw(41) << right << theOrders[i]->ItemsInOrder[j]->getItemNumber();
						cout << setw(33) << right << theOrders[i]->ItemsInOrder[j]->getItemDescription();
						cout << setw(11) << right << theOrders[i]->ItemsInOrder[j]->getSpecial1();
						cout << setw(12) << right << theOrders[i]->ItemsInOrder[j]->getSpecial2() << endl;
					}//if
				}//for

				cout << "--------------" << endl;

				cout << setw(21) << right << "Electronic Items Ordered:";
				cout << setw(16) << right << "Item Number";
				cout << setw(33) << right << "Item Description";
				cout << setw(11) << right << "Calories";
				cout << setw(12) << right << "Cost" << endl;

				cout << setw(41) << right << "-----------";
				cout << setw(33) << right << "--------------";
				cout << setw(11) << right << "--------";
				cout << setw(12) << right << "----" << endl;

				for(unsigned int j = 0; j < theOrders[i]->ItemsInOrder.size(); j++){
					if(theOrders[i]->ItemsInOrder[j]->whoAmI() == "electronicitem"){
						cout << setw(41) << right << theOrders[i]->ItemsInOrder[j]->getItemNumber();
						cout << setw(33) << right << theOrders[i]->ItemsInOrder[j]->getItemDescription();
						cout << setw(11) << right << theOrders[i]->ItemsInOrder[j]->getSpecial1();
						cout << setw(12) << right << theOrders[i]->ItemsInOrder[j]->getSpecial2() << endl;
					}//if
				}//for
				cout << "Total for this order will be: " << theOrders[i]->getTotalOrder(theOrders[i]->getOrderNumber()) << endl;

			}//for
		}
		else if(argc == 2){
			string aString = argv[1];
			if(aString == "ORDER100"){
				printOrder( 0, theOrders);
			}//if
			else if(aString == "ORDER200"){
				printOrder( 1, theOrders);
			}
			else if(aString == "ORDER300"){
				printOrder( 2, theOrders);
			}
			else{
				cout << "Invalid Order Number(ORDER100, ORDER200, ORDER300)" << endl;
			}
		}
		for(unsigned int i = 0; i < theCustomers.size(); i++){
			delete theCustomers[i];
		}
		for(unsigned int i = 0; i < theOrders.size(); i ++){
			delete theOrders[i];
		}
		theCustomers.clear();
		theOrders.clear();
	}


	return 0;
}//main

void printOrder(int anInt, vector<Order*> Orders){
	cout << "Order Report" << endl;

	cout << "=================================" << endl;

	cout << setw(15) << right << "Order ID";
	cout << setw(15) << right << "Customer ID";
	cout << setw(12) << right << "Order Date";
	cout << setw(15) << right << "Customer" << endl;

	cout << setw(15) << right << "--------";
	cout << setw(15) << right << "-----------";
	cout << setw(12) << right << "-----------";
	cout << setw(15) << right << "--------" << endl;

	cout << setw(15) << right << Orders[anInt]->getOrderNumber();
	cout << setw(15) << right << Orders[anInt]->getCustomerID();
	cout << setw(12) << right << Orders[anInt]->getOrderDate()->getDateStringThis();
	cout << setw(15) << right << Orders[anInt]->getOrderCustomer()->getCustomerName() << endl;


	cout << "--------------" << endl;

	cout << setw(21) << right << "Food Items Ordered:";
	cout << setw(20) << right << "Item Number";
	cout << setw(33) << right << "Item Description";
	cout << setw(11) << right << "Calories";
	cout << setw(12) << right << "Cost" << endl;

	cout << setw(41) << right << "-----------";
	cout << setw(33) << right << "--------------";
	cout << setw(11) << right << "--------";
	cout << setw(12) << right << "----" << endl;

	for(unsigned int j = 0; j < Orders[anInt]->ItemsInOrder.size(); j++){
		if(Orders[anInt]->ItemsInOrder[j]->whoAmI() == "fooditem"){
			cout << setw(41) << right << Orders[anInt]->ItemsInOrder[j]->getItemNumber();
			cout << setw(33) << right << Orders[anInt]->ItemsInOrder[j]->getItemDescription();
			cout << setw(11) << right << Orders[anInt]->ItemsInOrder[j]->getSpecial1();
			cout << setw(12) << right << Orders[anInt]->ItemsInOrder[j]->getSpecial2() << endl;
		}//if
		else{
		}//else

	}//for

	cout << "--------------" << endl;
	cout << setw(21) << right << "Media Items Ordered:";
	cout << setw(20) << right << "Item Number";
	cout << setw(33) << right << "Item Description";
	cout << setw(11) << right << "ISBN";
	cout << setw(12) << right << "Cost" << endl;

	cout << setw(41) << right << "-----------";
	cout << setw(33) << right << "--------------";
	cout << setw(11) << right << "----";
	cout << setw(12) << right << "----" << endl;

	for(unsigned int j = 0; j < Orders[anInt]->ItemsInOrder.size(); j++){
		if(Orders[anInt]->ItemsInOrder[j]->whoAmI() == "mediaitem"){
			cout << setw(41) << right << Orders[anInt]->ItemsInOrder[j]->getItemNumber();
			cout << setw(33) << right << Orders[anInt]->ItemsInOrder[j]->getItemDescription();
			cout << setw(11) << right << Orders[anInt]->ItemsInOrder[j]->getSpecial1();
			cout << setw(12) << right << Orders[anInt]->ItemsInOrder[j]->getSpecial2() << endl;
		}//if
	}//for

	cout << "--------------" << endl;

	cout << setw(21) << right << "Electronic Items Ordered:";
	cout << setw(16) << right << "Item Number";
	cout << setw(33) << right << "Item Description";
	cout << setw(11) << right << "Calories";
	cout << setw(12) << right << "Cost" << endl;

	cout << setw(41) << right << "-----------";
	cout << setw(33) << right << "--------------";
	cout << setw(11) << right << "--------";
	cout << setw(12) << right << "----" << endl;

	for(unsigned int j = 0; j < Orders[anInt]->ItemsInOrder.size(); j++){
		if(Orders[anInt]->ItemsInOrder[j]->whoAmI() == "electronicitem"){
			cout << setw(41) << right << Orders[anInt]->ItemsInOrder[j]->getItemNumber();
			cout << setw(33) << right << Orders[anInt]->ItemsInOrder[j]->getItemDescription();
			cout << setw(11) << right << Orders[anInt]->ItemsInOrder[j]->getSpecial1();
			cout << setw(12) << right << Orders[anInt]->ItemsInOrder[j]->getSpecial2() << endl;
		}//if
	}//for
	cout << "Total for this order will be: " << Orders[anInt]->getTotalOrder(Orders[anInt]->getOrderNumber()) << endl;
}

