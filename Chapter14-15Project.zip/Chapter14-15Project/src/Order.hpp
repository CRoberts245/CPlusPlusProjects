/*
 * Order.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef ORDER_HPP_
#define ORDER_HPP_
#include "Date.hpp"
#include "Customer.hpp"
#include "OrderItem.hpp"
#include "ElectronicItem.hpp"
#include "FoodItem.hpp"
#include "MedialItem.hpp"
#include <vector>
#include <fstream>
using namespace std;

class Order {
private:
	string OrderNumber;
	Date *OrderDate;
	Customer *OrderCustomer;
	string CustomerID;

public:
	Order(string);
	virtual ~Order();
	vector<OrderItem*> ItemsInOrder;
	string getOrderNumber(void);//accessors and mutators
	Date *getOrderDate(void);
	Customer *getOrderCustomer(void);
	string getCustomerID(void);
	void setCustomerID(string);
	void setOrderNumber(string);
	void setOrderDate(Date*);
	void setOrderCustomer(Customer*);

	void readFoodItems(void);
	void readMediaItems(void);
	void readElectronicItems(void);

	double getTotalOrder(string);
};

#endif /* ORDER_HPP_ */
