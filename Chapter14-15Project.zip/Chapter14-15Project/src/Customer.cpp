/*
 * Customer.cpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#include "Customer.hpp"

Customer::Customer() {
	// TODO Auto-generated constructor stub
	DateJoined = new Date();
}

Customer::~Customer() {
	// TODO Auto-generated destructor stub
	delete DateJoined;
}

string Customer::getCustomerNumber(void){
	return CustomerNumber;
}
string Customer::getCustomerName(void){
	return CustomerName;
}
string Customer::getEmail(void){
	return Email;
}
Date *Customer::getDateJoined(void){
	return DateJoined;
}

void Customer::setCustomerNumber(string aString){
	CustomerNumber = aString;
}
void Customer::setCustomerName(string aString){
	CustomerName = aString;
}
void Customer::setEmail(string aString){
	Email = aString;
}
void Customer::setDateJoined(Date *aDate){
	DateJoined = aDate;
}
