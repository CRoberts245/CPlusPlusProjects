/*
 * MedialItem.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef MEDIALITEM_HPP_
#define MEDIALITEM_HPP_

#include "OrderItem.hpp"
#include "Date.hpp"
class MedialItem: public OrderItem {
private:
	string AuthorName;
	Date PublicationDate;
	string ISBNNumber;
public:
	MedialItem();
	virtual ~MedialItem();

	string getAuthorName(void);
	Date getPublicationDate(void);
	string getISBNNumber(void);
	void setAuthorName(string);
	void setPublicationDate(Date);
	void setISBNNumber(string);
	string getSpecial1(void);
	string getSpecial2(void);

	string whoAmI(void);
};

#endif /* MEDIALITEM_HPP_ */
