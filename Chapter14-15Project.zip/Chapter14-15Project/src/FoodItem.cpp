/*
 * FoodItem.cpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#include "FoodItem.hpp"
#include <sstream>
FoodItem::FoodItem() {
	// TODO Auto-generated constructor stub

}

FoodItem::~FoodItem() {
	// TODO Auto-generated destructor stub
}

Date FoodItem::getExpirationDate(void){
	return ExpirationDate;
}
int FoodItem::getCalories(void){
	return Calories;
}
int FoodItem::getFat(void){
	return Fat;
}

void FoodItem::setExpirationDate(Date aDate){
	ExpirationDate = aDate;
}
void FoodItem::setCalories(int anInt){
	Calories = anInt;
}
void FoodItem::setFat(int anInt){
	Fat = anInt;
}

string FoodItem::whoAmI(void){
	return "fooditem";
}

string FoodItem::getSpecial1(void){
	ostringstream convert;
	convert << Calories;
	string newCalories = convert.str();
	convert.str("");
	return newCalories;
}
string FoodItem::getSpecial2(void){
	ostringstream convert;
	convert << this->getCustomerCost();
	string newCost = convert.str();
	convert.str("");
	return newCost;
}

