/*
 * ElectronicItem.cpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#include "ElectronicItem.hpp"
#include <sstream>
ElectronicItem::ElectronicItem() {
	// TODO Auto-generated constructor stub

}

ElectronicItem::~ElectronicItem() {
	// TODO Auto-generated destructor stub
}

string ElectronicItem::whoAmI(void){
	return "electronicitem";
}

Electronic ElectronicItem::getType(void){
	return Type;
}
int ElectronicItem::getWarrantyMonths(void){
	return WarrantyMonths;
}
void ElectronicItem::setType(Electronic theType){
	Type = theType;
}
void ElectronicItem::setWarrantyMonths(int anInt){
	WarrantyMonths = anInt;
}
string ElectronicItem::getSpecial1(void){
	ostringstream convert;
	convert << WarrantyMonths;
	string newWarranty = convert.str();
	convert.str("");
	return newWarranty;
}
string ElectronicItem::getSpecial2(void){
	ostringstream convert;
	convert << this->getCustomerCost();
	string newCost = convert.str();
	convert.str("");
	return newCost;
}
