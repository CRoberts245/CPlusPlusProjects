/*
 * ElectronicItem.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef ELECTRONICITEM_HPP_
#define ELECTRONICITEM_HPP_

#include "OrderItem.hpp"

class ElectronicItem: public OrderItem {
private:
	Electronic Type;
	int WarrantyMonths;

public:
	ElectronicItem();
	virtual ~ElectronicItem();

	string whoAmI(void);

	Electronic getType(void);
	int getWarrantyMonths(void);
	void setType(Electronic);
	void setWarrantyMonths(int);
	string getSpecial1(void);
	string getSpecial2(void);
};

#endif /* ELECTRONICITEM_HPP_ */
