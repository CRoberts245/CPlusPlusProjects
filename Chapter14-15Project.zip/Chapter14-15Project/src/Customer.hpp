/*
 * Customer.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef CUSTOMER_HPP_
#define CUSTOMER_HPP_
#include <iostream>
#include "Date.hpp"
using namespace std;

class Customer {
private:
	string CustomerNumber; //customer info, private members
	string CustomerName;
	string Email;
	Date *DateJoined;
public:
	Customer();
	virtual ~Customer();

	string getCustomerNumber(void);
	string getCustomerName(void);
	string getEmail(void);
	Date *getDateJoined(void);

	void setCustomerNumber(string);
	void setCustomerName(string);
	void setEmail(string);
	void setDateJoined(Date*);
};

#endif /* CUSTOMER_HPP_ */
