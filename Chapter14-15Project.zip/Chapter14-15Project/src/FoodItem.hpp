/*
 * FoodItem.hpp
 *
 *  Created on: Apr 26, 2017
 *      Author: Roberts
 */

#ifndef FOODITEM_HPP_
#define FOODITEM_HPP_

#include "OrderItem.hpp"
#include "Date.hpp"
using namespace std;
class FoodItem: public OrderItem {
private:
	Date ExpirationDate;
	int Calories;
	int Fat;
public:
	FoodItem();
	virtual ~FoodItem();

	Date getExpirationDate(void);
	int getCalories(void);
	int getFat(void);

	void setExpirationDate(Date);
	void setCalories(int);
	void setFat(int);
	string getSpecial1(void);
	string getSpecial2(void);

	string whoAmI(void);
};

#endif /* FOODITEM_HPP_ */
